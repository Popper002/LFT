public class test{ 
public  static void sum(int a,int b ){
 int  c= a+b;
 System.out.println("c="+c);  
}
public static void main(String[]args){ 
sum(10,2);
 }
}